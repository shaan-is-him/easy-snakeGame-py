from node import Node

class LinkedList:
    def __init__(self, start_pos):
        self.head = Node(start_pos)
        self.tail = self.head
        self.length = 1
        self.direction = 'RIGHT'

    def add_to_head(self, position):
        new_node = Node(position)
        new_node.next = self.head
        self.head = new_node
        self.length += 1

    def remove_tail(self):
        if not self.head or self.head == self.tail:
            self.head = self.tail = None
            self.length = 0
            return

        current = self.head
        while current.next != self.tail:
            current = current.next
        current.next = None
        self.tail = current
        self.length -= 1

    def get_head_position(self):
        return self.head.position if self.head else None

    def move(self):
        x, y = self.head.position
        if self.direction == 'UP': y -= 20
        elif self.direction == 'DOWN': y += 20
        elif self.direction == 'LEFT': x -= 20
        elif self.direction == 'RIGHT': x += 20
        self.add_to_head((x, y))
        self.remove_tail()

    def grow(self):
        x, y = self.head.position
        if self.direction == 'UP': y -= 20
        elif self.direction == 'DOWN': y += 20
        elif self.direction == 'LEFT': x -= 20
        elif self.direction == 'RIGHT': x += 20
        self.add_to_head((x, y))

    def change_direction(self, new_direction):
        opposite = {'UP': 'DOWN', 'DOWN': 'UP', 'LEFT': 'RIGHT', 'RIGHT': 'LEFT'}
        if new_direction != opposite.get(self.direction):
            self.direction = new_direction

    def contains(self, position):
        current = self.head.next  # Skip head
        while current:
            if current.position == position:
                return True
            current = current.next
        return False

    def get_positions(self):
        positions = []
        current = self.head
        while current:
            positions.append(current.position)
            current = current.next
        return positions

