class Node:
    def __init__(self, position):
        self.position = position
        self.next = None
