import pygame
import sys
from linked_list import LinkedList
from food import Food

pygame.init() 
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Snake Game with LinkedList Only")
clock = pygame.time.Clock()

snake = LinkedList((100, 100))
food = Food(WIDTH, HEIGHT)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                snake.change_direction('UP')
            elif event.key == pygame.K_DOWN:
                snake.change_direction('DOWN')
            elif event.key == pygame.K_LEFT:
                snake.change_direction('LEFT')
            elif event.key == pygame.K_RIGHT:
                snake.change_direction('RIGHT')

    snake.move()

    if snake.get_head_position() == food.position:
        snake.grow()
        food = Food(WIDTH, HEIGHT)

    if snake.contains(snake.get_head_position()):
        pygame.quit()
        sys.exit()

    head_x, head_y = snake.get_head_position()
    if not (0 <= head_x < WIDTH and 0 <= head_y < HEIGHT):
        pygame.quit()
        sys.exit()

    screen.fill((0, 0, 0))
    for pos in snake.get_positions():
        pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(pos[0], pos[1], 20, 20))

    pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(food.position[0], food.position[1], 20, 20))
    pygame.display.flip()
    clock.tick(3)