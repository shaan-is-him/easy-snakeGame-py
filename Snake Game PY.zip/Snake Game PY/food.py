import random

class Food:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.position = self.random_position()

    def random_position(self):
        x = random.randint(0, (self.width - 20) // 20) * 20
        y = random.randint(0, (self.height - 20) // 20) * 20
        return (x, y)